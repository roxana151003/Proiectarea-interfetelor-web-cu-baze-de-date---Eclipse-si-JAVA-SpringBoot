package com.example.demo.service;
import java.util.List; 
import com.example.demo.entity.Trupa; 
public interface TrupaService { 
	List<Trupa> getAllTrupa(); 
	Trupa saveTrupa(Trupa trupa); 
	Trupa getTrupaById(Long idtrupa); 
	Trupa updateTrupa(Trupa trupa); 
	void deleteTrupaById(Long idtrupa); 

}
