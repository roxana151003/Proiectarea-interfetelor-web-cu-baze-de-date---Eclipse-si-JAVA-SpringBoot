package com.example.demo.service;
import java.util.List; 
import com.example.demo.entity.Festival;
public interface FestivalService { 
	List<Festival> getAllFestival(); 
	Festival saveFestival(Festival festival); 
	Festival getFestivalById(Long idfestival); 
	Festival updateFestival(Festival festival); 
	void deleteFestivalById(Long idfestival);

}
