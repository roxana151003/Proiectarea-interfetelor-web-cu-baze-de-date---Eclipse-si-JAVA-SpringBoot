package com.example.demo.controller;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model; 
import org.springframework.web.bind.annotation.GetMapping; 
import org.springframework.web.bind.annotation.ModelAttribute; 
import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.PostMapping; 
import com.example.demo.entity.Trupa; 
import com.example.demo.service.TrupaService; 
@Controller 
public class TrupaController { 
	private TrupaService trupaService; 
	public TrupaController(TrupaService trupaService) { 
	super(); 
	this.trupaService = trupaService; 
	} 
	// metoda handler care se ocupa cu lista trupelor, returnarea si vizualizarea lor 
	@GetMapping("/trupa") 
	public String listTrupa(Model model) { 
	model.addAttribute("trupa", trupaService.getAllTrupa()); 
	return "trupa"; 
	} 
	 @GetMapping("/trupa/new") 
	 public String createTrupaForm(Model model) { 
	   
	  // creaza obiectul Trupa pentru a stoca datele din formular 
	  Trupa trupa = new Trupa(); 
	  model.addAttribute("trupa", trupa); 
	  return "create_trupa"; 
	   
	 } 
	  
	 @PostMapping("/trupa") 
	 public String saveTrupa(@ModelAttribute("trupa") Trupa trupa) { 
	  trupaService.saveTrupa(trupa); 
	  return "redirect:/trupa"; 
	 } 
	  
	 @GetMapping("/trupa/edit/{idtrupa}") 
	 public String editTrupaForm(@PathVariable Long idtrupa, Model model) { 
	  model.addAttribute("trupa", trupaService.getTrupaById(idtrupa)); 
	  return "edit_trupa"; 
	 } 
	 
	 @PostMapping("/trupa/{idtrupa}") 
	 public String updateTrupa(@PathVariable Long idtrupa, 
	   @ModelAttribute("trupa") Trupa trupa, 
	   Model model) { 
	   
	  // preia Trupa din baza de date dupa campul idtrupa 
	  Trupa trupaExistent = trupaService.getTrupaById(idtrupa); 
	  trupaExistent.setIdtrupa(idtrupa); 
	  trupaExistent.setNume(trupa.getNume()); 
	  trupaExistent.setGen_muzical(trupa.getGen_muzical()); 
	  trupaExistent.setNr_membrii(trupa.getNr_membrii()); 
	// salveaza un obiect trupa modificat 
	  trupaService.updateTrupa(trupaExistent); 
	return "redirect:/trupa";   
	} 
	// metoda de tip handler folosita pentru a se ocupa cu cererea de stergere a trupei 
	@GetMapping("/trupa/{idtrupa}") 
	public String deleteTrupa(@PathVariable Long idtrupa) { 
	trupaService.deleteTrupaById(idtrupa); 
	return "redirect:/trupa"; 
	} 

}
