package com.example.demo.service.impl;
import java.util.List; 

import org.springframework.stereotype.Service; 
 
import com.example.demo.entity.Festival; 
import com.example.demo.repository.FestivalRepository; 
import com.example.demo.service.FestivalService; 
 
@Service 
public class FestivalServiceImpl implements FestivalService{ 
	 
	 private FestivalRepository FestivalRepository; 
	  
	 public FestivalServiceImpl(FestivalRepository FestivalRepository) 
	{ 
	  super(); 
	  this.FestivalRepository = FestivalRepository; 
	 } 
	 
	 @Override 
	 public List<Festival> getAllFestival() { 
	  return FestivalRepository.findAll(); 
	 } 
	 
	 @Override 
	 public Festival saveFestival(Festival Festival) { 
	  return FestivalRepository.save(Festival); 
	 } 
	 
	 @Override 
	 public Festival getFestivalById(Long idfestival) { 
	  return FestivalRepository.findById(idfestival).get(); 
	 } 
	 
	 @Override 
	 public Festival updateFestival(Festival Festival) { 
	  return FestivalRepository.save(Festival); 
	 } 
	 
	 @Override 
	 public void deleteFestivalById(Long idfestival) { 
	  FestivalRepository.deleteById(idfestival);  
	 } 

}
