package com.example.demo.controller;
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model; 
import org.springframework.web.bind.annotation.GetMapping; 
import org.springframework.web.bind.annotation.ModelAttribute; 
import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.PostMapping; 
import com.example.demo.entity.Lista; 
import com.example.demo.service.ListaService; 
import com.example.demo.entity.Trupa; 
import com.example.demo.repository.FestivalRepository; 
import com.example.demo.repository.TrupaRepository; 
import com.example.demo.entity.Festival; 
@Controller
public class ListaController { 
	private ListaService listaService; 
	@Autowired 
	private TrupaRepository trupaRepo; 
	@Autowired 
	private FestivalRepository festivalRepo; 
	public ListaController(ListaService listaService) { 
	super(); 
	this.listaService = listaService; 
	} 
	@GetMapping("/lista") 
	 public String listLista(Model model) { 
	  model.addAttribute("lista", listaService.getAllLista()); 
	  return "lista"; 
	 } 
	  
	 @GetMapping("/lista/new") 
	 public String createListaForm(Model model) { 
	  List<Trupa> toatetrupele = trupaRepo.findAll(); 
	  List<Festival> toatefestivalele = festivalRepo.findAll(); 
	   
	  Lista lista = new Lista(); 
	  model.addAttribute("lista", lista); 
	   
	  model.addAttribute("toatetrupele", toatetrupele); 
	  model.addAttribute("toatefestivalele", toatefestivalele); 
	   
	  return "create_lista"; 
	   
	 } 
	  
	 @PostMapping("/lista") 
	 public String saveLista(@ModelAttribute("lista") Lista lista) {   
	  listaService.saveLista(lista); 
	  return "redirect:/lista"; 
	 } 
	   
	 @GetMapping("/lista/edit/{idlista}") 
	 public String editFestivalForm(@PathVariable Long idlista, Model model) { 
	  List<Trupa> toatetrupele = trupaRepo.findAll(); 
	  List<Festival> toatefestivalele = festivalRepo.findAll(); 
	 
	  model.addAttribute("lista", 
	listaService.getListaById(idlista)); 
	  model.addAttribute("toatetrupele", toatetrupele); 
	  model.addAttribute("toatefestivalele", toatefestivalele);
	return null; 
	   
	 } 
	 
	 @PostMapping("/lista/{idlista}") 
	 public String updateLista(@PathVariable Long idlista, 
	   @ModelAttribute("lista") Lista lista,  Model model) { 
	   
	  Lista listaExistenta = listaService.getListaById(idlista); 
	  listaExistenta.setIdlista(idlista); 
	  listaExistenta.setTrupa(lista.getTrupa()); 
	  listaExistenta.setFestival(lista.getFestival()); 
	 
	 listaExistenta.setDansatori(lista.getDansatori()); 
	  listaExistenta.setOra_trupa(lista.getOra_trupa()); 
	  listaExistenta.setScena(lista.getScena()); 
	 
	  listaService.updateLista(listaExistenta); 
	  return "redirect:/lista";   
	 } 
	  
	  
	 @GetMapping("/lista/{idlista}") 
	 public String deleteLista(@PathVariable Long idlista) { 
	  listaService.deleteListaById(idlista); 
	  return "redirect:/lista"; 
	}

}
