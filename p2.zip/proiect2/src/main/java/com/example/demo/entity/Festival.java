package com.example.demo.entity;
import jakarta.persistence.*; 

@Entity 
@Table(name = "festival") 
public class Festival {
	 
	 @Id 
	 @GeneratedValue(strategy = GenerationType.IDENTITY) 
	 private Long idfestival; 
	 
	 @Column(name = "Nume", nullable = false) 
	 private String Nume; 
	 
	 @Column(name = "Data") 
	 private String Data; 
	 
	 @Column(name = "Pret_bilet") 
	 private String Pret_bilet; 
	 
	 public Festival() { 
	 
	 } 
	 
	 public Festival(String Nume, String Data, String Pret_bilet) { 
	  super(); 
	  this.Nume = Nume; 
	  this.Data = Data; 
	  this.Pret_bilet = Pret_bilet; 
	 } 
	 
	 public Long getIdfestival() { 
	return idfestival; 
	} 
	public void setIdfestival(Long idfestival) { 
	this.idfestival = idfestival; 
	} 
	public String getNume() { 
	return Nume; 
	} 
	public void setNume(String Nume) { 
	this.Nume = Nume; 
	} 
	public String getData() { 
	return Data; 
	} 
	public void setData(String Data) { 
	this.Data = Data; 
	} 
	public String getPret_bilet() { 
	return Pret_bilet; 
	} 
	public void setPret_bilet(String Pret_bilet) { 
	this.Pret_bilet = Pret_bilet; 
	}

}
