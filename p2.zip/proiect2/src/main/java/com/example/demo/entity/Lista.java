package com.example.demo.entity;

//import java.time.LocalTime;
//import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.*;

@Entity
@Table(name = "lista")
public class Lista {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idlista;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "idfestival", nullable = false)
    private Festival festival;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "idtrupa", nullable = false)
    private Trupa trupa;

    @Column(name = "Dansatori", nullable = false)
    private String dansatori;

    @Column(name = "Scena")
    private String scena;

    @Column(name = "Ora_trupa")
    private String Ora_trupa;

    public Lista() {
    }

    public Lista(Festival festival, Trupa trupa, String dansatori, String scena, String Ora_trupa) {
        super();
        this.festival = festival;
        this.trupa = trupa;
        this.dansatori = dansatori;
        this.scena = scena;
        this.Ora_trupa = Ora_trupa;
    }

    public Long getIdlista() {
        return this.idlista;
    }

    public void setIdlista(Long idlista) {
        this.idlista = idlista;
    }

    public Festival getFestival() {
        return this.festival;
    }

    public void setFestival(Festival festival) {
        this.festival = festival;
    }

    public Trupa getTrupa() {
        return this.trupa;
    }

    public void setTrupa(Trupa trupa) {
        this.trupa = trupa;
    }

    public String getDansatori() {
        return this.dansatori;
    }

    public void setDansatori(String dansatori) {
        this.dansatori = dansatori;
    }

    public String getScena() {
        return this.scena;
    }

    public void setScena(String scena) {
        this.scena = scena;
    }

    public String getOra_trupa() {
        return this.Ora_trupa;
    }

    public void setOra_trupa(String Ora_trupa) {
        this.Ora_trupa = Ora_trupa;
    }
}
