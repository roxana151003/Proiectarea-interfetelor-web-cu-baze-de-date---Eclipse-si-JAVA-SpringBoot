package com.example.demo.service.impl;

import java.util.List; 

import org.springframework.stereotype.Service; 

import com.example.demo.entity.Lista; 
import com.example.demo.repository.ListaRepository; 
import com.example.demo.service.ListaService; 

@Service 
public class ListaServiceImpl  implements ListaService{ 
	 
	 private ListaRepository ListaRepository; 
	  
	 public ListaServiceImpl(ListaRepository 
	ListaRepository) { 
	  super(); 
	  this.ListaRepository = ListaRepository; 
	 } 
	 
	 @Override 
	 public List<Lista> getAllLista() { 
	  return ListaRepository.findAll(); 
	 } 
	 
	 @Override 
	 public Lista saveLista(Lista 
	Lista) { 
	  return ListaRepository.save(Lista); 
	 } 
	 
	 @Override 
	 public Lista getListaById(Long idlista) 
	{ 
	  return 
	ListaRepository.findById(idlista).get(); 
	 } 
	 
	 @Override 
	 public Lista updateLista(Lista Lista) { 
	  return ListaRepository.save(Lista); 
	 } 
	 
	 @Override 
	 public void deleteListaById(Long idlista) { 
	  ListaRepository.deleteById(idlista);  
	 }

}
