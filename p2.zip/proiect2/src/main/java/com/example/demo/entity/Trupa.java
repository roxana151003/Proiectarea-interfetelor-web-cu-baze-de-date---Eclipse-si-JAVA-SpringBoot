package com.example.demo.entity;
import jakarta.persistence.*; 
@Entity 
@Table(name = "trupa") 
public class Trupa {
	@Id 
	 @GeneratedValue(strategy = GenerationType.IDENTITY) 
	 private Long idtrupa; 
	 
	 @Column(name = "Nume", nullable = false) 
	 private String Nume; 
	 
	 @Column(name = "Gen_muzical") 
	 private String Gen_muzical; 
	 
	 @Column(name = "Nr_membrii") 
	 private String Nr_membrii; 
	 
	 public Trupa() { 
	 
	 } 
	 
	 public Trupa(String Nume, String Gen_muzical, String Nr_membrii) { 
	  super(); 
	  this.Nume = Nume; 
	  this.Gen_muzical =Gen_muzical; 
	  this.Nr_membrii= Nr_membrii; 
	 } 
	 
	 public Long getIdtrupa() { 
	  return idtrupa; 
	 } 
	 
	 public void setIdtrupa(Long idtrupa) { 
	  this.idtrupa = idtrupa; 
	 } 
	 
	 public String getNume() { 
	  return Nume; 
	 } 
	 
	 public void setNume(String Nume) { 
	  this.Nume = Nume; 
	 } 
	 
	 public String getGen_muzical() { 
	  return Gen_muzical; 
	 } 
	 
	 public void setGen_muzical(String Gen_muzical) { 
	  this.Gen_muzical = Gen_muzical; 
	 } 
	 
	 public String getNr_membrii() { 
	  return Nr_membrii; 
	 } 
	 
	 public void setNr_membrii(String Nr_membrii) { 
	  this.Nr_membrii = Nr_membrii; 
	 }

}
