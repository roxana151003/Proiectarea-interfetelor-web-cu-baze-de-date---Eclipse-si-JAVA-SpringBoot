package com.example.demo.service;
import java.util.List; 
import com.example.demo.entity.Lista; 
public interface ListaService { 
	List<Lista> getAllLista(); 
	Lista saveLista(Lista lista); 
	Lista getListaById(Long idlista); 
	Lista updateLista(Lista lista); 
	void deleteListaById(Long idlista); 

}
