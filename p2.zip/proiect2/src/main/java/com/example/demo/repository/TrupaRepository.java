package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository; 
import com.example.demo.entity.Trupa; 
public interface TrupaRepository extends 
JpaRepository<Trupa, Long>{ 
} 
