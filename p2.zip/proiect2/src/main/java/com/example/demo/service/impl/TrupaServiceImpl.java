package com.example.demo.service.impl;
import java.util.List; 
import org.springframework.stereotype.Service; 
 
import com.example.demo.entity.Trupa; 
import com.example.demo.repository.TrupaRepository; 
import com.example.demo.service.TrupaService; 
 
@Service 
public class TrupaServiceImpl implements TrupaService{ 
	 
	 private TrupaRepository TrupaRepository; 
	  
	 public TrupaServiceImpl(TrupaRepository TrupaRepository) { 
	  super(); 
	  this.TrupaRepository = TrupaRepository; 
	 } 
	 
	 @Override 
	 public List<Trupa> getAllTrupa() { 
	  return TrupaRepository.findAll(); 
	 } 
	 
	 @Override 
	 public Trupa saveTrupa(Trupa Trupa) { 
	  return TrupaRepository.save(Trupa); 
	 } 
	 
	 @Override 
	 public Trupa getTrupaById(Long idtrupa) { 
	  return TrupaRepository.findById(idtrupa).get(); 
	 } 
	 
	 @Override 
	 public Trupa updateTrupa(Trupa Trupa) { 
	  return TrupaRepository.save(Trupa); 
	 } 
	 
	 @Override 
	 public void deleteTrupaById(Long idtrupa) { 
	  TrupaRepository.deleteById(idtrupa);  
	 }

}
