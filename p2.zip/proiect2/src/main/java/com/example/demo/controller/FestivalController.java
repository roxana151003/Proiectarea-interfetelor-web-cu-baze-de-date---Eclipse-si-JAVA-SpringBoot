package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Festival;
import com.example.demo.service.FestivalService;

@Controller
public class FestivalController {

    private final FestivalService festivalService;

    public FestivalController(FestivalService festivalService) {
        this.festivalService = festivalService;
    }

    @GetMapping("/festival")
    public String listFestival(Model model) {
        model.addAttribute("festival", festivalService.getAllFestival());
        return "festival"; // Asigură-te că ai un fișier festival.html în templates
    }

    @GetMapping("/festival/new")
    public String createFestivalForm(Model model) {
        Festival festival = new Festival();
        model.addAttribute("festival", festival);
        return "create_festival"; // Asigură-te că ai un fișier create_festival.html în templates
    }

    @PostMapping("/festival")
    public String saveFestival(@ModelAttribute("festival") Festival festival) {
        festivalService.saveFestival(festival);
        return "redirect:/festival";
    }

    @GetMapping("/festival/edit/{idfestival}")
    public String editFestivalForm(@PathVariable Long idfestival, Model model) {
        Festival festival = festivalService.getFestivalById(idfestival);
        if (festival == null) {
            throw new RuntimeException("Festival not found with ID: " + idfestival);
        }
        model.addAttribute("festival", festival);
        return "edit_festival"; // Asigură-te că ai un fișier edit_festival.html în templates
    }

    @PostMapping("/festival/{idfestival}")
    public String updateFestival(
            @PathVariable Long idfestival,
            @ModelAttribute("festival") Festival festival,
            Model model) {

        // Găsește festivalul existent după ID
        Festival festivalExistent = festivalService.getFestivalById(idfestival);
        if (festivalExistent == null) {
            throw new RuntimeException("Festival not found with ID: " + idfestival);
        }

        // Actualizează câmpurile
        festivalExistent.setNume(festival.getNume());
        festivalExistent.setData(festival.getData());
        festivalExistent.setPret_bilet(festival.getPret_bilet());

        festivalService.updateFestival(festivalExistent);
        return "redirect:/festival";
    }

    @GetMapping("/festival/{idfestival}")
    public String deleteFestival(@PathVariable Long idfestival) {
        festivalService.deleteFestivalById(idfestival);
        return "redirect:/festival";
    }
}
